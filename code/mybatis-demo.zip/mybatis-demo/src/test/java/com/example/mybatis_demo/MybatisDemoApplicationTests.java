package com.example.mybatis_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybatisDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
