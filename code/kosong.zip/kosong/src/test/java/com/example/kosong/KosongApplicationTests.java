package com.example.kosong;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KosongApplicationTests {

	@Test
	void contextLoads() {
	}

}
