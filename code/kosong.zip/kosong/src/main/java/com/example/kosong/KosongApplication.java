package com.example.kosong;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KosongApplication {

	public static void main(String[] args) {
		SpringApplication.run(KosongApplication.class, args);
	}

}
